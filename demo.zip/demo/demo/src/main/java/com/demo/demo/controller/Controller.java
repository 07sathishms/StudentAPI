package com.demo.demo.controller;

import com.demo.demo.Entity.Student;
import com.demo.demo.Service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class Controller {
    @Autowired
    private StudentService studentService;


    @PostMapping ("/students")
    public ResponseEntity<?> saveStudent(@RequestBody Student student) {
            studentService.saveStudent(student);
            return new ResponseEntity<>("Student Details Created sucessfully!!!", HttpStatus.OK);
        }
    @GetMapping("/students")
   public ResponseEntity<?> fetchStudent(){
        return new ResponseEntity<>( studentService.fetchStudent(),HttpStatus.OK);
    }
    @DeleteMapping("/students/{id}")
    public ResponseEntity<?> deleteByid(@PathVariable("id") Long studentid) {
        try {
            if (studentid != null) {
                studentService.deleteByid(studentid);
            }
                return new ResponseEntity<>("Students Details Deleted SuccessFully!!!", HttpStatus.OK);

        } catch (Exception e) {
            return new ResponseEntity<>("Student Details not found!!!", HttpStatus.OK);
        }
    }
    @PutMapping("/students/{id}")
    public ResponseEntity<?> updateByid(@PathVariable("id") Long studentid, @RequestBody Student student){
        try {

            if (studentid != null)
                studentService.updateByid(studentid, student);
            return new ResponseEntity<>("Student details updated Successfully!!!", HttpStatus.OK);
        }catch (Exception e) {
            return new ResponseEntity<>("Student details not found!!!", HttpStatus.OK);
        }


    }


}
