package com.demo.demo.Entity;

import javax.persistence.*;

@Entity
public class Student {
   @Id
   @GeneratedValue(strategy = GenerationType.AUTO)
    private  long studentId;

    public Student() {
    }
    @Column(name = "firstname")
    private String firstname;

    public Student(long studentId, String firstname, String lastname, String email, String dep) {
        this.studentId = studentId;
        this.firstname = firstname;
        this.lastname = lastname;
        this.email = email;
        this.dep = dep;
    }

    private String lastname;

    public long getStudentId() {
        return studentId;
    }

    public void setStudentId(long studentId) {
        this.studentId = studentId;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDep() {
        return dep;
    }

    public void setDep(String dep) {
        this.dep = dep;
    }

    private String email;
    private String dep;
}
