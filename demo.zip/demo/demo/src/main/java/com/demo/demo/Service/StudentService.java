package com.demo.demo.Service;

import com.demo.demo.Entity.Student;
import com.demo.demo.Repo.StudentRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentService {
    @Autowired
    private StudentRepo studentRepo;


    public Student saveStudent(Student student){

        return studentRepo.save(student);
    }

    public List<Student> fetchStudent() {

        return studentRepo.findAll();
    }

    public void deleteByid(Long studentid) {

        studentRepo.deleteById(studentid);
    }

    public Student updateByid(Long studentid, Student student) {
        Student student1 = studentRepo.getReferenceById(studentid);
       student1.setEmail(student.getEmail());
       student1.setFirstname(student.getFirstname());
       student1.setLastname(student.getLastname());
       student1.setDep(student.getDep());
       return studentRepo.save(student1);

    }
}
